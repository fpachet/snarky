"""Frozen corpus integrity and independent first-order learning/DP checks."""

import json
from fractions import Fraction
from itertools import product

from benchmarks.blues_corpus import SIMPLIFICATION, training_sequences
from benchmarks.blues_markov import CORPUS, reference_dp, train


def test_frozen_variants_transposition_multiplicity_and_review_map():
    corpus = json.loads(CORPUS.read_text())
    assert len(corpus["sequences"]) == 22
    assert len(corpus["changes"]) == 31
    assert corpus["simplification"] == SIMPLIFICATION
    for variant, expected_alphabet in (
        ("source_faithful", 60),
        ("paper_style_proposed", 36),
    ):
        normalized = training_sequences(corpus, variant, all_keys=False)
        augmented = training_sequences(corpus, variant, all_keys=True)
        assert len(normalized) == 22 and len(augmented) == 264
        assert all(len(sequence) == 24 for sequence in augmented)
        assert (
            len({symbol for sequence in augmented for symbol in sequence})
            == expected_alphabet
        )
        assert tuple(augmented[i * 12] for i in range(22)) == normalized
        assert tuple(tuple(s[variant]) for s in corpus["sequences"]) == normalized
    alice = next(
        s for s in corpus["sequences"] if s["transcription_id"] == "Blues_For_Alice"
    )
    assert alice["source_faithful"][:2] == ["C", "C"]
    assert alice["paper_style_proposed"][:2] == ["C7", "C7"]


def test_counts_do_not_cross_sequence_boundaries_and_initial_is_symbol_marginal():
    source = train((("a", "b", "b"), ("c", "a")))
    assert source.initial == {
        "a": Fraction(2, 5),
        "b": Fraction(2, 5),
        "c": Fraction(1, 5),
    }
    assert source.transitions == {("a", "b"): 1, ("b", "b"): 1, ("c", "a"): 1}
    assert ("b", "c") not in source.transitions


def test_exact_counter_dp_matches_brute_force():
    source = train((("a", "b", "a", "a"), ("b", "b", "a", "b")))
    domains = (("a",), source.alphabet, source.alphabet, source.alphabet, ("b",))
    for counted in (None, "b"):
        target = 2
        expected = [
            (source.score(row), row)
            for row in product(*domains)
            if counted is None or row.count(counted) == target
        ]
        optimum = reference_dp(source, domains, counted, target)
        assert optimum[0] == max(value for value, _ in expected)
        assert optimum in expected
