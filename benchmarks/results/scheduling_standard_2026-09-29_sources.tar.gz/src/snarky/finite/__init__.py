"""Experimental declarative finite models; independent of legacy CHOICE weights."""

from .constraints import (
    AllOfConstraint,
    AnyOfConstraint,
    AvailabilityConstraint,
    CapacityConstraint,
    NValueConstraint,
    ResourceLoadConstraint,
    Task,
    WorkloadConstraint,
)
from .factors import FactorObjective, IntegerFactor, ScoreContribution, TableFactor
from .inference import InferenceSummary, infer
from .language import ModelDocument, QueryRequest, parse_model_document
from .markov import MarkovCosts, markov_model
from .measure import Measure, WeightTable, negative_log2_measure
from .model import (
    FactConstraint,
    FiniteModel,
    FiniteVariable,
    GuardedConstraint,
    IncumbentRecord,
    LinearObjective,
    PredicateConstraint,
    Query,
    QueryKind,
    QueryResult,
    ResultStatus,
    Solution,
    Termination,
)
from .oracle import enumerate_model
from .product_objective import RationalProductObjective
from .scheduling import (
    Capacity,
    Coverage,
    ExactlyOne,
    NoOverlap,
    OptionalTask,
    Precedence,
    StartWindow,
    Workload,
    availability_constraints,
    no_overlap_constraints,
    resource_capacity_constraints,
)
from .scheduling_symmetry import interchangeable_task_constraints
from .search import solve
from .variable_markov import MarkovGeneration, MarkovGraph, MarkovOptimum, NGramModel

__all__ = [
    "interchangeable_task_constraints",
    "AllOfConstraint",
    "AvailabilityConstraint",
    "ResourceLoadConstraint",
    "WorkloadConstraint",
    "Coverage",
    "ExactlyOne",
    "StartWindow",
    "Workload",
    "no_overlap_constraints",
    "resource_capacity_constraints",
    "AnyOfConstraint",
    "Capacity",
    "CapacityConstraint",
    "FactConstraint",
    "FactorObjective",
    "FiniteModel",
    "FiniteVariable",
    "GuardedConstraint",
    "IncumbentRecord",
    "IntegerFactor",
    "InferenceSummary",
    "LinearObjective",
    "MarkovCosts",
    "MarkovGeneration",
    "MarkovGraph",
    "MarkovOptimum",
    "NGramModel",
    "NValueConstraint",
    "NoOverlap",
    "OptionalTask",
    "Precedence",
    "Measure",
    "ModelDocument",
    "PredicateConstraint",
    "Query",
    "QueryKind",
    "QueryResult",
    "QueryRequest",
    "ResultStatus",
    "RationalProductObjective",
    "ScoreContribution",
    "Solution",
    "Termination",
    "TableFactor",
    "Task",
    "WeightTable",
    "enumerate_model",
    "availability_constraints",
    "markov_model",
    "infer",
    "negative_log2_measure",
    "parse_model_document",
    "solve",
]
