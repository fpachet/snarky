"""Persistent index-assisted joins and semi-naïve instantiation."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from functools import cache

from ..computed import ComputedPremise
from ..facts import Fact
from ..matching import PatternMatcher
from ..premises import (
    BindPremise,
    CollectPremise,
    CountPremise,
    ExistsPremise,
    UniquePremise,
)
from ..rules import Rule
from ..substitutions import (
    EMPTY_SUBSTITUTION,
    BindingFrame,
    Substitution,
)
from ..terms import (
    FiniteSet,
    Term,
    Variable,
    is_ground,
    variables_in,
)
from .base import (
    Activation,
    FactDelta,
    InstantiationMetrics,
    WitnessCacheKey,
)
from .compiled import (
    CompiledAggregatePremise,
    CompiledBindPremise,
    CompiledBlock,
    CompiledCollectPremise,
    CompiledCombinationsPremise,
    CompiledComparisonPremise,
    CompiledExistentialPremise,
    CompiledFactPremise,
    all_fact_plans,
    compile_rule,
    negative_fact_plans,
    simple_fact_plan,
)
from .event_rules import (
    compile_event_rule,
    compile_factorized_event_rule,
    instantiate_event_rule,
    instantiate_factorized_event_rule,
)
from .fact_index import FactIndex as FactIndex
from .fact_index import _structural_lookup
from .query_memory import (
    QueryMemory,
    aggregate_witness_supports,
    facts_match_plans,
)
from .semi_naive_join import has_query_premise, join_delta_variants

_RESIDUAL_WITNESS_MIN_FACTS = 128


def _apply_compiled_binding(
    premise: BindPremise | ComputedPremise,
    frame: BindingFrame,
) -> bool:
    if isinstance(premise, BindPremise):
        bound_value = frame.apply(premise.value)
        return is_ground(bound_value) and frame.bind_ground(
            premise.target,
            bound_value,
        )
    accepted, computed_value = premise.resolve(frame)
    if not accepted:
        return False
    if premise.target is None:
        return True
    assert computed_value is not None
    return frame.bind_ground(premise.target, computed_value)


@dataclass(frozen=True, slots=True)
class _RuleMemory:
    activations: tuple[Activation, ...]


@dataclass(frozen=True, slots=True)
class _PartialState:
    substitution: Substitution
    supports: tuple[Fact, ...]


@dataclass(slots=True)
class _PartialStateLookup:
    variables: tuple[Variable, ...]
    buckets: dict[tuple[Term, ...], list[_PartialState]]


@dataclass(slots=True)
class _SemiNaivePositiveMemory:
    levels: list[list[_PartialState]]
    keys: list[
        set[
            tuple[
                tuple[tuple[str, Term], ...],
                tuple[Fact, ...],
            ]
        ]
    ]
    lookups: list[_PartialStateLookup | None]
    state_count: int


class IndexedInstantiationStrategy:
    """Use persistent exact indexes while preserving exhaustive joins.

    One index is shared by the rules evaluated over the same working-memory
    snapshot. Premises and candidates keep their naïve insertion order, so
    this strategy changes work but not observable results.
    """

    supports_fact_view = True

    def __init__(
        self,
        matcher: PatternMatcher | None = None,
        *,
        partial_join_limit: int = 2_048,
    ) -> None:
        if partial_join_limit < 1:
            raise ValueError("partial_join_limit must be positive")
        self.matcher = matcher or PatternMatcher()
        self.partial_join_limit = partial_join_limit
        self.metrics = InstantiationMetrics()
        self._index: FactIndex | None = None
        self._pending_removed: set[Fact] = set()
        self._query_memory = QueryMemory()
        self._witness_cache = self._query_memory.witness_cache
        self._query_blocks = self._query_memory.blocks
        self._query_counts = self._query_memory.counts
        self._simple_query_facts = self._query_memory.simple_facts
        self._query_aggregate_supports = (
            self._query_memory.aggregate_supports
        )
        self._residual_witnesses = self._query_memory.residual_witnesses
        self._rule_memories: dict[Rule, _RuleMemory] = {}
        self._positive_join_memories: dict[
            Rule, tuple[tuple[_PartialState, ...], ...]
        ] = {}
        self._partial_memory_disabled: set[Rule] = set()

    def instantiate(
        self,
        rule: Rule,
        facts: Sequence[Fact],
        delta: FactDelta | tuple[Fact, ...] | None = None,
    ) -> tuple[Activation, ...]:
        changes = _normalize_delta(delta)
        index = self._index_for(facts, changes)
        positive_rule = self._is_positive_compiled_rule(rule)
        if (
            positive_rule
            and rule not in self._partial_memory_disabled
            and rule not in self._positive_join_memories
            and not self._should_materialize_positive(rule, index)
        ):
            self._partial_memory_disabled.add(rule)
            self.metrics.partial_join_bypasses += 1
        if positive_rule and rule not in self._partial_memory_disabled:
            result = self._instantiate_positive_memory(
                rule,
                index,
                changes,
            )
            if result is not None:
                self.metrics.activations_produced += len(result)
                self._rule_memories[rule] = _RuleMemory(result)
                return result
        reused = self._reuse_rule_memory(rule, changes)
        if reused is not None:
            self.metrics.activations_produced += len(reused)
            return reused
        activations = self._join(rule, index)
        self.metrics.activations_produced += len(activations)
        result = tuple(activations)
        self._rule_memories[rule] = _RuleMemory(result)
        return result

    def invalidate(self, removed: frozenset[Fact] = frozenset()) -> None:
        """Apply removals to the shared index, or discard it if unspecified."""

        if self._index is None:
            return
        if not removed:
            self._index = None
            self._pending_removed.clear()
            self._query_memory.clear(reset_revision=True)
            self._rule_memories.clear()
            self._positive_join_memories.clear()
            self._partial_memory_disabled.clear()
            return
        self._pending_removed.update(removed)
        self._invalidate_query_memories((), removed)

    def synchronize(
        self,
        facts: Sequence[Fact],
        delta: FactDelta,
    ) -> None:
        """Consume fact changes without instantiating an unrelated rule."""

        self._index_for(facts, delta)

    def fork_for_branch(self) -> IndexedInstantiationStrategy:
        """Return a clean strategy seeded from the current immutable index."""

        branch = IndexedInstantiationStrategy(
            self.matcher,
            partial_join_limit=self.partial_join_limit,
        )
        if self._index is not None:
            branch._index = self._index.clone(metrics=branch.metrics)
        return branch

    def query_view(self) -> IndexedInstantiationStrategy:
        """Return a clean query strategy sharing the current fact index.

        The view is intended for read-only queries over the same fact
        snapshot. Query-local witnesses and rule memories remain isolated.
        """

        view = IndexedInstantiationStrategy(
            self.matcher,
            partial_join_limit=self.partial_join_limit,
        )
        view._index = self._index
        return view

    @staticmethod
    def _is_positive_compiled_rule(rule: Rule) -> bool:
        return all(
            isinstance(
                premise,
                (CompiledFactPremise, CompiledComparisonPremise),
            )
            for premise in compile_rule(rule).block.premises
        )

    def _instantiate_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
        delta: FactDelta | None,
    ) -> tuple[Activation, ...] | None:
        memory = self._positive_join_memories.get(rule)
        if memory is None or delta is None:
            memory = self._build_positive_memory(rule, index)
            if memory is not None:
                self.metrics.partial_join_builds += 1
        elif delta.changed:
            memory = self._update_positive_memory(
                rule,
                index,
                memory,
                delta,
            )
            if memory is not None:
                self.metrics.partial_join_updates += 1
        else:
            self.metrics.activation_cache_hits += 1
        if memory is None:
            self._positive_join_memories.pop(rule, None)
            self._partial_memory_disabled.add(rule)
            return None
        self._positive_join_memories[rule] = memory
        return tuple(
            Activation(state.substitution, state.supports)
            for state in memory[-1]
        )

    def _should_materialize_positive(
        self,
        rule: Rule,
        index: FactIndex,
    ) -> bool:
        estimate = 1
        frame = BindingFrame()
        for premise in compile_rule(rule).block.premises:
            if not isinstance(premise, CompiledFactPremise):
                continue
            estimate *= max(
                1,
                len(index.candidates_compiled(premise, frame)),
            )
            if estimate > self.partial_join_limit:
                return False
        return True

    def _build_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
    ) -> tuple[tuple[_PartialState, ...], ...] | None:
        levels: list[tuple[_PartialState, ...]] = [
            (_PartialState(EMPTY_SUBSTITUTION, ()),)
        ]
        for premise in compile_rule(rule).block.premises:
            if not isinstance(
                premise,
                (CompiledFactPremise, CompiledComparisonPremise),
            ):
                raise TypeError(
                    f"non-positive compiled premise: {premise!r}"
                )
            remaining = self.partial_join_limit - sum(
                len(level) for level in levels
            )
            levels.append(
                self._advance_positive_states(
                    levels[-1],
                    premise,
                    index,
                    max_states=remaining + 1,
                )
            )
            if sum(len(level) for level in levels) > self.partial_join_limit:
                return None
        return tuple(levels)

    def _update_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
        memory: tuple[tuple[_PartialState, ...], ...],
        delta: FactDelta,
    ) -> tuple[tuple[_PartialState, ...], ...] | None:
        retained_levels = [
            tuple(
                state
                for state in level
                if delta.removed.isdisjoint(state.supports)
            )
            for level in memory
        ]
        if delta.removed:
            self.metrics.activation_cache_filtered += sum(
                len(previous) - len(retained)
                for previous, retained in zip(
                    memory,
                    retained_levels,
                    strict=True,
                )
            )
        if not delta.added:
            self.metrics.activation_cache_hits += 1
            return tuple(retained_levels)

        updated: list[tuple[_PartialState, ...]] = [retained_levels[0]]
        new_prefixes: tuple[_PartialState, ...] = ()
        for position, premise in enumerate(
            compile_rule(rule).block.premises
        ):
            retained_current = retained_levels[position]
            retained_next = retained_levels[position + 1]
            generated: list[_PartialState] = []
            if isinstance(premise, CompiledComparisonPremise):
                generated.extend(
                    state
                    for state in new_prefixes
                    if premise.source.evaluate(state.substitution)
                )
            elif isinstance(premise, CompiledFactPremise):
                generated.extend(
                    self._advance_positive_fact_states(
                        new_prefixes,
                        premise,
                        index,
                    )
                )
                generated.extend(
                    self._advance_positive_fact_states(
                        retained_current,
                        premise,
                        index,
                        candidates=delta.added,
                    )
                )
            else:
                raise TypeError(
                    f"non-positive compiled premise: {premise!r}"
                )
            existing_keys = {
                _partial_state_key(state) for state in retained_next
            }
            unique_new: dict[
                tuple[
                    tuple[tuple[str, Term], ...],
                    tuple[Fact, ...],
                ],
                _PartialState,
            ] = {}
            for state in generated:
                key = _partial_state_key(state)
                if key not in existing_keys:
                    unique_new.setdefault(key, state)
            new_prefixes = tuple(unique_new.values())
            combined = (*retained_next, *new_prefixes)
            ordered = tuple(
                sorted(
                    combined,
                    key=lambda state: tuple(
                        index.ranks[fact] for fact in state.supports
                    ),
                )
            )
            updated.append(ordered)
            if sum(len(level) for level in updated) > self.partial_join_limit:
                return None
        return tuple(updated)

    def _advance_positive_states(
        self,
        states: tuple[_PartialState, ...],
        premise: CompiledFactPremise | CompiledComparisonPremise,
        index: FactIndex,
        *,
        max_states: int | None = None,
    ) -> tuple[_PartialState, ...]:
        if isinstance(premise, CompiledComparisonPremise):
            output = tuple(
                state
                for state in states
                if premise.source.evaluate(state.substitution)
            )
            return output if max_states is None else output[:max_states]
        return self._advance_positive_fact_states(
            states,
            premise,
            index,
            max_states=max_states,
        )

    def _advance_positive_fact_states(
        self,
        states: tuple[_PartialState, ...],
        premise: CompiledFactPremise,
        index: FactIndex,
        *,
        candidates: Sequence[Fact] | None = None,
        max_states: int | None = None,
    ) -> tuple[_PartialState, ...]:
        output: list[_PartialState] = []
        candidate_filter = (
            frozenset(candidates) if candidates is not None else None
        )
        for state in states:
            frame = BindingFrame(state.substitution.items())
            indexed_candidates = index.candidates_compiled(premise, frame)
            selected = (
                indexed_candidates
                if candidate_filter is None
                else tuple(
                    fact
                    for fact in indexed_candidates
                    if fact in candidate_filter
                )
            )
            self.metrics.candidate_facts += len(selected)
            for fact in selected:
                self.metrics.match_attempts += 1
                checkpoint = frame.checkpoint()
                if premise.match(fact.entity, fact.status, frame):
                    output.append(
                        _PartialState(
                            frame.freeze(),
                            (*state.supports, fact),
                        )
                    )
                    if (
                        max_states is not None
                        and len(output) >= max_states
                    ):
                        return tuple(output)
                frame.rollback(checkpoint)
        return tuple(output)

    def _reuse_rule_memory(
        self,
        rule: Rule,
        delta: FactDelta | None,
    ) -> tuple[Activation, ...] | None:
        memory = self._rule_memories.get(rule)
        if memory is None or delta is None or delta.added:
            return None
        if not delta.removed:
            self.metrics.activation_cache_hits += 1
            return memory.activations
        if any(
            isinstance(
                premise,
                (
                    ExistsPremise,
                    CountPremise,
                    UniquePremise,
                    CollectPremise,
                ),
            )
            for premise in rule.premises
        ):
            return None
        if self._removal_can_enable_negative(rule, delta.removed):
            return None
        retained = tuple(
            activation
            for activation in memory.activations
            if delta.removed.isdisjoint(activation.premise_facts)
        )
        self.metrics.activation_cache_hits += 1
        self.metrics.activation_cache_filtered += (
            len(memory.activations) - len(retained)
        )
        self._rule_memories[rule] = _RuleMemory(retained)
        return retained

    @staticmethod
    def _removal_can_enable_negative(
        rule: Rule,
        removed: frozenset[Fact],
    ) -> bool:
        dependencies = negative_fact_plans(compile_rule(rule).block)
        if not dependencies:
            return False
        frame = BindingFrame()
        for fact in removed:
            for premise in dependencies:
                checkpoint = frame.checkpoint()
                matches = premise.match(fact.entity, fact.status, frame)
                frame.rollback(checkpoint)
                if matches:
                    return True
        return False

    def _index_for(
        self,
        facts: Sequence[Fact],
        delta: FactDelta | None,
    ) -> FactIndex:
        if delta is not None:
            self._apply_query_delta(delta)
        if delta is not None and delta.removed:
            self._pending_removed.update(delta.removed)
        index = self._index
        if index is None:
            index = FactIndex(facts, metrics=self.metrics)
            self._index = index
            self._pending_removed.clear()
            self._query_memory.clear()
            self.metrics.index_builds += 1
            self.metrics.indexed_facts += len(facts)
            return index
        if self._pending_removed:
            removed = frozenset(self._pending_removed)
            removal_count = index.remove(removed)
            self.metrics.index_removals += removal_count
            self._pending_removed.clear()

        if delta is None:
            indexed = tuple(index.facts)
            if tuple(facts[: len(indexed)]) == indexed:
                added = index.extend(facts[len(indexed) :])
                self.metrics.indexed_facts += added
            elif indexed != tuple(facts):
                index = FactIndex(facts, metrics=self.metrics)
                self._index = index
                if delta is None:
                    self._query_memory.clear()
                self.metrics.index_builds += 1
                self.metrics.indexed_facts += len(facts)
            return index

        if delta is not None and delta.added:
            added = index.extend(delta.added)
            self.metrics.indexed_facts += added
        return index

    def _apply_query_delta(self, delta: FactDelta) -> None:
        if (
            delta.revision
            and delta.revision <= self._query_memory.processed_revision
        ):
            return
        if not self._query_memory.registrations:
            if delta.revision:
                self._query_memory.processed_revision = delta.revision
            return
        if delta.changed:
            self._invalidate_query_memories(delta.added, delta.removed)
        if delta.revision:
            self._query_memory.processed_revision = delta.revision

    def _invalidate_query_memories(
        self,
        added: tuple[Fact, ...],
        removed: frozenset[Fact],
    ) -> None:
        candidates = self._query_memory.affected_keys(added, removed)

        expired: list[WitnessCacheKey] = []
        for key in candidates:
            if key in self._simple_query_facts:
                self._update_simple_query(key, added, removed)
                continue
            block = self._query_blocks[key]
            witness = self._witness_cache.get(key)
            residuals = self._residual_witnesses.get(key)
            if residuals is not None and removed:
                remaining_residuals = tuple(
                    residual
                    for residual in residuals
                    if removed.isdisjoint(residual)
                )
                if remaining_residuals:
                    if remaining_residuals != residuals:
                        promoted = (
                            remaining_residuals[0] != residuals[0]
                        )
                        self._register_query_memory(
                            key,
                            block,
                            remaining_residuals[0],
                            residual_witnesses=remaining_residuals,
                        )
                        if promoted:
                            self.metrics.residual_witness_promotions += 1
                    continue
                expired.append(key)
                continue
            if witness is not None and any(
                fact in removed for fact in witness
            ):
                expired.append(key)
                continue
            bindings = (
                (Variable(name), term)
                for name, term in key[1]
            )
            frame = BindingFrame(bindings)
            negative = negative_fact_plans(block)
            if removed and facts_match_plans(removed, negative, frame):
                expired.append(key)
                continue
            if added and negative and facts_match_plans(
                added,
                negative,
                frame,
            ):
                expired.append(key)
                continue
            if (
                added
                and witness is None
                and facts_match_plans(
                    added,
                    all_fact_plans(block),
                    frame,
                )
            ):
                expired.append(key)
        for key in expired:
            self._remove_query_registration(key)
        self.metrics.witness_cache_invalidations += len(expired)

    def _update_simple_query(
        self,
        key: WitnessCacheKey,
        added: tuple[Fact, ...],
        removed: frozenset[Fact],
    ) -> None:
        block = self._query_blocks[key]
        plan = simple_fact_plan(block)
        if plan is None:
            raise TypeError("simple query memory requires one fact premise")
        previous = self._simple_query_facts[key]
        matching = [fact for fact in previous if fact not in removed]
        frame = BindingFrame(
            (Variable(name), term)
            for name, term in key[1]
        )
        for fact in added:
            if fact in matching:
                continue
            checkpoint = frame.checkpoint()
            matches = plan.match(fact.entity, fact.status, frame)
            frame.rollback(checkpoint)
            if matches:
                matching.append(fact)
        current = tuple(matching)
        if current == previous:
            return
        witness = (current[0],) if current else None
        self._register_query_memory(
            key,
            block,
            witness,
            simple_facts=current,
        )
        self.metrics.query_counter_updates += 1

    def _register_query_memory(
        self,
        key: WitnessCacheKey,
        block: CompiledBlock,
        witness: tuple[Fact, ...] | None,
        *,
        simple_facts: tuple[Fact, ...] | None = None,
        count_value: int | None = None,
        aggregate_supports: tuple[Fact, ...] = (),
        residual_witnesses: tuple[tuple[Fact, ...], ...] = (),
    ) -> None:
        self._query_memory.register(
            key,
            block,
            witness,
            use_structural_watches=(
                self._index is not None
                and len(self._index) >= _RESIDUAL_WITNESS_MIN_FACTS
            ),
            simple_facts=simple_facts,
            count_value=count_value,
            aggregate_supports=aggregate_supports,
            residual_witnesses=residual_witnesses,
        )

    def _remove_query_registration(
        self,
        key: WitnessCacheKey,
    ) -> None:
        self._query_memory.remove(key)

    def _join(
        self,
        rule: Rule,
        index: FactIndex,
    ) -> list[Activation]:
        activations: list[Activation] = []
        frame = BindingFrame()
        self._extend_compiled(
            compile_rule(rule).block,
            index,
            premise_index=0,
            frame=frame,
            supports=[],
            output=activations,
        )
        return activations

    def _extend_compiled(
        self,
        block: CompiledBlock,
        index: FactIndex,
        premise_index: int,
        frame: BindingFrame,
        supports: list[Fact],
        output: list[Activation],
    ) -> None:
        if premise_index == len(block.premises):
            output.append(Activation(frame.freeze(), tuple(supports)))
            return
        premise = block.premises[premise_index]
        if isinstance(premise, CompiledComparisonPremise):
            if premise.source.evaluate(frame):
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            return
        if isinstance(premise, CompiledBindPremise):
            checkpoint = frame.checkpoint()
            if _apply_compiled_binding(premise.source, frame):
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCombinationsPremise):
            for value in premise.source.values(frame):
                checkpoint = frame.checkpoint()
                if frame.bind_ground(premise.source.target, value):
                    self._extend_compiled(
                        block,
                        index,
                        premise_index + 1,
                        frame,
                        supports,
                        output,
                    )
                frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCollectPremise):
            collection, collection_supports = self._collect_compiled_values(
                premise,
                index,
                frame,
            )
            checkpoint = frame.checkpoint()
            if frame.bind_ground(premise.source.target, collection):
                support_count = len(supports)
                supports.extend(collection_supports)
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledAggregatePremise):
            count_value, aggregate_supports = self._count_compiled_query(
                premise.block,
                index,
                frame,
            )
            if _aggregate_accepts(premise.source, count_value):
                support_count = len(supports)
                supports.extend(aggregate_supports)
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if isinstance(premise, CompiledExistentialPremise):
            witness = self._first_compiled_witness(
                premise.block,
                index,
                frame,
            )
            succeeds = witness is not None
            if premise.negated:
                succeeds = not succeeds
                witness = ()
            if succeeds:
                support_count = len(supports)
                supports.extend(witness or ())
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if not isinstance(premise, CompiledFactPremise):
            raise TypeError(f"unsupported compiled premise: {premise!r}")
        candidates = index.candidates_compiled(premise, frame)
        self.metrics.candidate_facts += len(candidates)
        for fact in candidates:
            self.metrics.match_attempts += 1
            checkpoint = frame.checkpoint()
            if premise.match(fact.entity, fact.status, frame):
                supports.append(fact)
                self._extend_compiled(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                supports.pop()
            frame.rollback(checkpoint)

    def _first_compiled_witness(
        self,
        block: CompiledBlock,
        index: FactIndex,
        frame: BindingFrame,
    ) -> tuple[Fact, ...] | None:
        key = (
            block.source,
            frame.projected_key(block.correlated_variables),
        )
        if key in self._witness_cache:
            self.metrics.witness_cache_hits += 1
            return self._witness_cache[key]
        self.metrics.witness_cache_misses += 1
        simple_plan = simple_fact_plan(block)
        if simple_plan is not None:
            matching_facts: list[Fact] = []
            candidates = index.candidates_compiled(simple_plan, frame)
            self.metrics.candidate_facts += len(candidates)
            for fact in candidates:
                self.metrics.match_attempts += 1
                checkpoint = frame.checkpoint()
                if simple_plan.match(fact.entity, fact.status, frame):
                    matching_facts.append(fact)
                frame.rollback(checkpoint)
            simple_facts = tuple(matching_facts)
            simple_witness = (simple_facts[0],) if simple_facts else None
            self._register_query_memory(
                key,
                block,
                simple_witness,
                simple_facts=simple_facts,
            )
            return simple_witness
        if self._can_retain_residual_witnesses(block, index, frame):
            checkpoint = frame.checkpoint()
            residuals: list[tuple[Fact, ...]] = []
            self._collect_bounded_fact_witnesses(
                block,
                index,
                remaining=tuple(range(len(block.premises))),
                frame=frame,
                selected=[],
                output=residuals,
                limit=2,
            )
            frame.rollback(checkpoint)
            residual_tuple = tuple(residuals)
            witness = residual_tuple[0] if residual_tuple else None
            self._register_query_memory(
                key,
                block,
                witness,
                residual_witnesses=residual_tuple,
            )
            return witness
        checkpoint = frame.checkpoint()
        supports: list[Fact] = []
        witness = self._first_compiled_witness_from(
            block,
            index,
            premise_index=0,
            frame=frame,
            supports=supports,
        )
        frame.rollback(checkpoint)
        self._register_query_memory(key, block, witness)
        return witness

    @staticmethod
    def _can_retain_residual_witnesses(
        block: CompiledBlock,
        index: FactIndex,
        frame: BindingFrame,
    ) -> bool:
        return (
            len(index) >= _RESIDUAL_WITNESS_MIN_FACTS
            and
            len(block.premises) > 1
            and all(
                isinstance(premise, CompiledFactPremise)
                for premise in block.premises
            )
            and any(
                _structural_lookup(premise, frame) is not None
                for premise in block.premises
                if isinstance(premise, CompiledFactPremise)
            )
        )

    def _collect_bounded_fact_witnesses(
        self,
        block: CompiledBlock,
        index: FactIndex,
        *,
        remaining: tuple[int, ...],
        frame: BindingFrame,
        selected: list[tuple[int, Fact]],
        output: list[tuple[Fact, ...]],
        limit: int,
    ) -> None:
        """Retain a small number of alternatives for a structured join."""

        if len(output) >= limit:
            return
        if not remaining:
            output.append(
                tuple(
                    fact
                    for _, fact in sorted(
                        selected,
                        key=lambda item: item[0],
                    )
                )
            )
            return
        choices: list[
            tuple[int, int, CompiledFactPremise, Sequence[Fact]]
        ] = []
        for position in remaining:
            premise = block.premises[position]
            assert isinstance(premise, CompiledFactPremise)
            candidates = index.candidates_compiled(premise, frame)
            choices.append((len(candidates), position, premise, candidates))
        _, position, premise, candidates = min(
            choices,
            key=lambda choice: (choice[0], choice[1]),
        )
        if position != remaining[0]:
            self.metrics.adaptive_join_reorders += 1
        self.metrics.candidate_facts += len(candidates)
        for fact in candidates:
            self.metrics.match_attempts += 1
            checkpoint = frame.checkpoint()
            if premise.match(fact.entity, fact.status, frame):
                selected.append((position, fact))
                self._collect_bounded_fact_witnesses(
                    block,
                    index,
                    remaining=tuple(
                        candidate
                        for candidate in remaining
                        if candidate != position
                    ),
                    frame=frame,
                    selected=selected,
                    output=output,
                    limit=limit,
                )
                selected.pop()
            frame.rollback(checkpoint)
            if len(output) >= limit:
                return

    def _first_compiled_witness_from(
        self,
        block: CompiledBlock,
        index: FactIndex,
        premise_index: int,
        frame: BindingFrame,
        supports: list[Fact],
    ) -> tuple[Fact, ...] | None:
        if premise_index == len(block.premises):
            return tuple(supports)
        premise = block.premises[premise_index]
        if isinstance(premise, CompiledComparisonPremise):
            if not premise.source.evaluate(frame):
                return None
            return self._first_compiled_witness_from(
                block,
                index,
                premise_index + 1,
                frame,
                supports,
            )
        if isinstance(premise, CompiledBindPremise):
            checkpoint = frame.checkpoint()
            if not _apply_compiled_binding(premise.source, frame):
                frame.rollback(checkpoint)
                return None
            witness = self._first_compiled_witness_from(
                block,
                index,
                premise_index + 1,
                frame,
                supports,
            )
            frame.rollback(checkpoint)
            return witness
        if isinstance(premise, CompiledCombinationsPremise):
            for value in premise.source.values(frame):
                checkpoint = frame.checkpoint()
                if frame.bind_ground(premise.source.target, value):
                    witness = self._first_compiled_witness_from(
                        block,
                        index,
                        premise_index + 1,
                        frame,
                        supports,
                    )
                    frame.rollback(checkpoint)
                    if witness is not None:
                        return witness
                else:
                    frame.rollback(checkpoint)
            return None
        if isinstance(premise, CompiledCollectPremise):
            collection, collection_supports = self._collect_compiled_values(
                premise,
                index,
                frame,
            )
            checkpoint = frame.checkpoint()
            if not frame.bind_ground(premise.source.target, collection):
                frame.rollback(checkpoint)
                return None
            support_count = len(supports)
            supports.extend(collection_supports)
            witness = self._first_compiled_witness_from(
                block,
                index,
                premise_index + 1,
                frame,
                supports,
            )
            del supports[support_count:]
            frame.rollback(checkpoint)
            return witness
        if isinstance(premise, CompiledAggregatePremise):
            count_value, aggregate_supports = self._count_compiled_query(
                premise.block,
                index,
                frame,
            )
            if not _aggregate_accepts(premise.source, count_value):
                return None
            support_count = len(supports)
            supports.extend(aggregate_supports)
            witness = self._first_compiled_witness_from(
                block,
                index,
                premise_index + 1,
                frame,
                supports,
            )
            del supports[support_count:]
            return witness
        if isinstance(premise, CompiledExistentialPremise):
            nested = self._first_compiled_witness(
                premise.block,
                index,
                frame,
            )
            succeeds = nested is not None
            if premise.negated:
                succeeds = not succeeds
                nested = ()
            if not succeeds:
                return None
            support_count = len(supports)
            supports.extend(nested or ())
            witness = self._first_compiled_witness_from(
                block,
                index,
                premise_index + 1,
                frame,
                supports,
            )
            del supports[support_count:]
            return witness
        if not isinstance(premise, CompiledFactPremise):
            raise TypeError(f"unsupported compiled premise: {premise!r}")
        group_end = premise_index
        while (
            group_end < len(block.premises)
            and isinstance(
                block.premises[group_end],
                CompiledFactPremise,
            )
        ):
            group_end += 1
        group_positions = tuple(range(premise_index, group_end))
        if not (
            len(index) >= _RESIDUAL_WITNESS_MIN_FACTS
            and any(
                _structural_lookup(candidate, frame) is not None
                for candidate in block.premises[premise_index:group_end]
                if isinstance(candidate, CompiledFactPremise)
            )
        ):
            candidates = index.candidates_compiled(premise, frame)
            self.metrics.candidate_facts += len(candidates)
            for fact in candidates:
                self.metrics.match_attempts += 1
                checkpoint = frame.checkpoint()
                if premise.match(fact.entity, fact.status, frame):
                    supports.append(fact)
                    witness = self._first_compiled_witness_from(
                        block,
                        index,
                        premise_index + 1,
                        frame,
                        supports,
                    )
                    supports.pop()
                    frame.rollback(checkpoint)
                    if witness is not None:
                        return witness
                else:
                    frame.rollback(checkpoint)
            return None
        return self._first_compiled_fact_group(
            block,
            index,
            remaining=group_positions,
            next_index=group_end,
            frame=frame,
            supports=supports,
            selected=[],
        )

    def _first_compiled_fact_group(
        self,
        block: CompiledBlock,
        index: FactIndex,
        *,
        remaining: tuple[int, ...],
        next_index: int,
        frame: BindingFrame,
        supports: list[Fact],
        selected: list[tuple[int, Fact]],
    ) -> tuple[Fact, ...] | None:
        """Join one positive block from its currently smallest bucket."""

        if not remaining:
            support_count = len(supports)
            supports.extend(
                fact for _, fact in sorted(selected, key=lambda item: item[0])
            )
            witness = self._first_compiled_witness_from(
                block,
                index,
                next_index,
                frame,
                supports,
            )
            del supports[support_count:]
            return witness
        choices: list[
            tuple[int, int, CompiledFactPremise, Sequence[Fact]]
        ] = []
        for position in remaining:
            candidate_premise = block.premises[position]
            assert isinstance(candidate_premise, CompiledFactPremise)
            candidate_facts = index.candidates_compiled(
                candidate_premise,
                frame,
            )
            choices.append(
                (
                    len(candidate_facts),
                    position,
                    candidate_premise,
                    candidate_facts,
                )
            )
        _, position, premise, candidates = min(
            choices,
            key=lambda choice: (choice[0], choice[1]),
        )
        if position != remaining[0]:
            self.metrics.adaptive_join_reorders += 1
        self.metrics.candidate_facts += len(candidates)
        for fact in candidates:
            self.metrics.match_attempts += 1
            checkpoint = frame.checkpoint()
            if premise.match(fact.entity, fact.status, frame):
                selected.append((position, fact))
                witness = self._first_compiled_fact_group(
                    block,
                    index,
                    remaining=tuple(
                        candidate
                        for candidate in remaining
                        if candidate != position
                    ),
                    next_index=next_index,
                    frame=frame,
                    supports=supports,
                    selected=selected,
                )
                selected.pop()
                frame.rollback(checkpoint)
                if witness is not None:
                    return witness
            else:
                frame.rollback(checkpoint)
        return None

    def _count_compiled_query(
        self,
        block: CompiledBlock,
        index: FactIndex,
        frame: BindingFrame,
    ) -> tuple[int, tuple[Fact, ...]]:
        key = (
            block.source,
            frame.projected_key(block.correlated_variables),
        )
        if key in self._query_counts:
            self.metrics.witness_cache_hits += 1
            return (
                self._query_counts[key],
                self._query_aggregate_supports[key],
            )
        self.metrics.witness_cache_misses += 1
        if key in self._witness_cache:
            self._remove_query_registration(key)

        simple_plan = simple_fact_plan(block)
        if simple_plan is not None:
            matching_facts: list[Fact] = []
            candidates = index.candidates_compiled(simple_plan, frame)
            self.metrics.candidate_facts += len(candidates)
            for fact in candidates:
                self.metrics.match_attempts += 1
                checkpoint = frame.checkpoint()
                if simple_plan.match(fact.entity, fact.status, frame):
                    matching_facts.append(fact)
                frame.rollback(checkpoint)
            simple_facts = tuple(matching_facts)
            witness = (simple_facts[0],) if simple_facts else None
            self._register_query_memory(
                key,
                block,
                witness,
                simple_facts=simple_facts,
            )
            return len(simple_facts), simple_facts

        checkpoint = frame.checkpoint()
        supports: list[Fact] = []
        witnesses: list[tuple[Fact, ...]] = []
        self._collect_compiled_witnesses_from(
            block,
            index,
            premise_index=0,
            frame=frame,
            supports=supports,
            output=witnesses,
        )
        frame.rollback(checkpoint)
        witness_tuple = tuple(witnesses)
        aggregate_supports = aggregate_witness_supports(witness_tuple)
        first = witness_tuple[0] if witness_tuple else None
        self._register_query_memory(
            key,
            block,
            first,
            count_value=len(witness_tuple),
            aggregate_supports=aggregate_supports,
        )
        return len(witness_tuple), aggregate_supports

    def _collect_compiled_witnesses_from(
        self,
        block: CompiledBlock,
        index: FactIndex,
        premise_index: int,
        frame: BindingFrame,
        supports: list[Fact],
        output: list[tuple[Fact, ...]],
    ) -> None:
        if premise_index == len(block.premises):
            output.append(tuple(supports))
            return
        premise = block.premises[premise_index]
        if isinstance(premise, CompiledComparisonPremise):
            if premise.source.evaluate(frame):
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            return
        if isinstance(premise, CompiledBindPremise):
            checkpoint = frame.checkpoint()
            if _apply_compiled_binding(premise.source, frame):
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCombinationsPremise):
            for value in premise.source.values(frame):
                checkpoint = frame.checkpoint()
                if frame.bind_ground(premise.source.target, value):
                    self._collect_compiled_witnesses_from(
                        block,
                        index,
                        premise_index + 1,
                        frame,
                        supports,
                        output,
                    )
                frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCollectPremise):
            collection, collection_supports = self._collect_compiled_values(
                premise,
                index,
                frame,
            )
            checkpoint = frame.checkpoint()
            if frame.bind_ground(premise.source.target, collection):
                support_count = len(supports)
                supports.extend(collection_supports)
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledExistentialPremise):
            nested = self._first_compiled_witness(
                premise.block,
                index,
                frame,
            )
            succeeds = nested is not None
            if premise.negated:
                succeeds = not succeeds
                nested = ()
            if succeeds:
                support_count = len(supports)
                supports.extend(nested or ())
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if isinstance(premise, CompiledAggregatePremise):
            count_value, aggregate_supports = self._count_compiled_query(
                premise.block,
                index,
                frame,
            )
            if _aggregate_accepts(premise.source, count_value):
                support_count = len(supports)
                supports.extend(aggregate_supports)
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if not isinstance(premise, CompiledFactPremise):
            raise TypeError(f"unsupported compiled premise: {premise!r}")
        candidates = index.candidates_compiled(premise, frame)
        self.metrics.candidate_facts += len(candidates)
        for fact in candidates:
            self.metrics.match_attempts += 1
            checkpoint = frame.checkpoint()
            if premise.match(fact.entity, fact.status, frame):
                supports.append(fact)
                self._collect_compiled_witnesses_from(
                    block,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                supports.pop()
            frame.rollback(checkpoint)

    def _collect_compiled_values(
        self,
        premise: CompiledCollectPremise,
        index: FactIndex,
        frame: BindingFrame,
    ) -> tuple[FiniteSet, tuple[Fact, ...]]:
        checkpoint = frame.checkpoint()
        projected: list[tuple[Term, tuple[Fact, ...]]] = []
        self._collect_compiled_projection_from(
            premise.block,
            premise.source.projection,
            index,
            premise_index=0,
            frame=frame,
            supports=[],
            output=projected,
        )
        frame.rollback(checkpoint)
        collection = FiniteSet(
            tuple(dict.fromkeys(value for value, _ in projected))
        )
        supports = tuple(
            dict.fromkeys(
                fact
                for _, witness_supports in projected
                for fact in witness_supports
            )
        )
        return collection, supports

    def _collect_compiled_projection_from(
        self,
        block: CompiledBlock,
        projection: Term,
        index: FactIndex,
        premise_index: int,
        frame: BindingFrame,
        supports: list[Fact],
        output: list[tuple[Term, tuple[Fact, ...]]],
    ) -> None:
        if premise_index == len(block.premises):
            value = frame.apply(projection)
            if not is_ground(value):
                raise ValueError("COLLECT projection must be ground")
            output.append((value, tuple(supports)))
            return
        premise = block.premises[premise_index]
        if isinstance(premise, CompiledComparisonPremise):
            if premise.source.evaluate(frame):
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            return
        if isinstance(premise, CompiledBindPremise):
            checkpoint = frame.checkpoint()
            if _apply_compiled_binding(premise.source, frame):
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCombinationsPremise):
            for value in premise.source.values(frame):
                checkpoint = frame.checkpoint()
                if frame.bind_ground(premise.source.target, value):
                    self._collect_compiled_projection_from(
                        block,
                        projection,
                        index,
                        premise_index + 1,
                        frame,
                        supports,
                        output,
                    )
                frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledCollectPremise):
            collection, collection_supports = self._collect_compiled_values(
                premise,
                index,
                frame,
            )
            checkpoint = frame.checkpoint()
            if frame.bind_ground(premise.source.target, collection):
                support_count = len(supports)
                supports.extend(collection_supports)
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            frame.rollback(checkpoint)
            return
        if isinstance(premise, CompiledAggregatePremise):
            count_value, aggregate_supports = self._count_compiled_query(
                premise.block,
                index,
                frame,
            )
            if _aggregate_accepts(premise.source, count_value):
                support_count = len(supports)
                supports.extend(aggregate_supports)
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if isinstance(premise, CompiledExistentialPremise):
            witness = self._first_compiled_witness(
                premise.block,
                index,
                frame,
            )
            succeeds = witness is not None
            if premise.negated:
                succeeds = not succeeds
                witness = ()
            if succeeds:
                support_count = len(supports)
                supports.extend(witness or ())
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                del supports[support_count:]
            return
        if not isinstance(premise, CompiledFactPremise):
            raise TypeError(f"unsupported compiled premise: {premise!r}")
        candidates = index.candidates_compiled(premise, frame)
        self.metrics.candidate_facts += len(candidates)
        for fact in candidates:
            self.metrics.match_attempts += 1
            checkpoint = frame.checkpoint()
            if premise.match(fact.entity, fact.status, frame):
                supports.append(fact)
                self._collect_compiled_projection_from(
                    block,
                    projection,
                    index,
                    premise_index + 1,
                    frame,
                    supports,
                    output,
                )
                supports.pop()
            frame.rollback(checkpoint)

class SemiNaiveInstantiationStrategy(IndexedInstantiationStrategy):
    """Enumerate only joins containing a fact new to the current rule."""

    def __init__(
        self,
        matcher: PatternMatcher | None = None,
        *,
        partial_join_limit: int = 2_048,
        use_event_rules: bool = True,
        use_factorized_event_rules: bool = True,
        use_partial_join_memory: bool = True,
    ) -> None:
        super().__init__(
            matcher,
            partial_join_limit=partial_join_limit,
        )
        self.use_event_rules = use_event_rules
        self.use_factorized_event_rules = use_factorized_event_rules
        self.use_partial_join_memory = use_partial_join_memory
        self._semi_naive_positive_memories: dict[
            Rule, _SemiNaivePositiveMemory
        ] = {}
        self._semi_naive_partial_pending: set[Rule] = set()
        self._semi_naive_partial_disabled: set[Rule] = set()

    def fork_for_branch(self) -> SemiNaiveInstantiationStrategy:
        """Return a clean semi-naïve strategy seeded from the current index."""

        branch = SemiNaiveInstantiationStrategy(
            self.matcher,
            partial_join_limit=self.partial_join_limit,
            use_event_rules=self.use_event_rules,
            use_factorized_event_rules=self.use_factorized_event_rules,
            use_partial_join_memory=self.use_partial_join_memory,
        )
        if self._index is not None:
            branch._index = self._index.clone(metrics=branch.metrics)
        return branch

    def invalidate(self, removed: frozenset[Fact] = frozenset()) -> None:
        """Invalidate indexes and discard partial memories on a full reset."""

        super().invalidate(removed)
        if not removed:
            self._semi_naive_positive_memories.clear()
            self._semi_naive_partial_pending.clear()
            self._semi_naive_partial_disabled.clear()

    def instantiate(
        self,
        rule: Rule,
        facts: Sequence[Fact],
        delta: FactDelta | tuple[Fact, ...] | None = None,
    ) -> tuple[Activation, ...]:
        changes = _normalize_delta(delta)
        event_plan = (
            compile_event_rule(rule) if self.use_event_rules else None
        )
        if event_plan is not None:
            if self._index is not None:
                self._index_for(facts, changes)
            candidates = (
                facts
                if changes is None or changes.removed
                else changes.added
            )
            activations = instantiate_event_rule(
                event_plan,
                candidates,
                self.metrics,
            )
            self.metrics.activations_produced += len(activations)
            return tuple(activations)

        index = self._index_for(facts, changes)
        factorized_event_plan = (
            compile_factorized_event_rule(rule)
            if (
                self.use_event_rules
                and self.use_factorized_event_rules
                and changes is not None
                and bool(changes.added)
                and not changes.removed
            )
            else None
        )
        if factorized_event_plan is not None:
            assert changes is not None
            factorized_activations = instantiate_factorized_event_rule(
                factorized_event_plan,
                index,
                changes.added,
                self.metrics,
            )
            self.metrics.activations_produced += len(
                factorized_activations
            )
            return factorized_activations
        if self._can_use_semi_naive_positive_memory(rule):
            if (
                rule in self._semi_naive_positive_memories
                or rule in self._semi_naive_partial_pending
            ):
                partial_activations = (
                    self._instantiate_semi_naive_positive_memory(
                        rule,
                        index,
                        changes,
                    )
                )
                if partial_activations is not None:
                    self.metrics.activations_produced += len(
                        partial_activations
                    )
                    return partial_activations
            else:
                self._semi_naive_partial_pending.add(rule)
        if (
            changes is None
            or changes.removed
            or (changes.added and has_query_premise(rule))
        ):
            activations = self._join(rule, index)
        elif not changes.added:
            activations = []
        else:
            activations = join_delta_variants(
                rule,
                index,
                changes.added,
                self.metrics,
            )
        self.metrics.activations_produced += len(activations)
        return tuple(activations)

    def _can_use_semi_naive_positive_memory(self, rule: Rule) -> bool:
        if (
            not self.use_partial_join_memory
            or rule in self._semi_naive_partial_disabled
        ):
            return False
        return _has_reusable_positive_prefix(rule)

    def _instantiate_semi_naive_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
        delta: FactDelta | None,
    ) -> tuple[Activation, ...] | None:
        memory = self._semi_naive_positive_memories.get(rule)
        if memory is None or delta is None:
            built = self._build_semi_naive_positive_memory(rule, index)
            if built is None:
                self._disable_semi_naive_positive_memory(rule)
                return None
            memory, activations = built
            self._semi_naive_positive_memories[rule] = memory
            self._semi_naive_partial_pending.discard(rule)
            self.metrics.partial_join_builds += 1
            if delta is None:
                return activations
            if delta.removed:
                return activations
            if not delta.added:
                return ()
            added = frozenset(delta.added)
            return tuple(
                activation
                for activation in activations
                if not added.isdisjoint(activation.premise_facts)
            )
        if not delta.changed:
            self.metrics.activation_cache_hits += 1
            return ()
        updated_activations = self._update_semi_naive_positive_memory(
            rule,
            index,
            memory,
            delta,
        )
        if updated_activations is None:
            self._disable_semi_naive_positive_memory(rule)
            return None
        self.metrics.partial_join_updates += 1
        return updated_activations

    def _disable_semi_naive_positive_memory(self, rule: Rule) -> None:
        self._semi_naive_positive_memories.pop(rule, None)
        self._semi_naive_partial_pending.discard(rule)
        self._semi_naive_partial_disabled.add(rule)
        self.metrics.partial_join_bypasses += 1

    def _build_semi_naive_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
    ) -> tuple[
        _SemiNaivePositiveMemory,
        tuple[Activation, ...],
    ] | None:
        compiled_premises = compile_rule(rule).block.premises
        premises = tuple(
            premise
            for premise in compiled_premises
            if isinstance(
                premise,
                (CompiledFactPremise, CompiledComparisonPremise),
            )
        )
        if len(premises) != len(compiled_premises):
            raise TypeError("partial memory requires a positive rule")
        levels: list[list[_PartialState]] = [
            [_PartialState(EMPTY_SUBSTITUTION, ())]
        ]
        keys = [{_partial_state_key(levels[0][0])}]
        state_count = 1
        for premise in premises[:-1]:
            states = list(
                self._advance_positive_states(
                    tuple(levels[-1]),
                    premise,
                    index,
                    max_states=(
                        self.partial_join_limit - state_count + 1
                        if isinstance(premise, CompiledFactPremise)
                        else None
                    ),
                )
            )
            if isinstance(premise, CompiledFactPremise):
                state_count += len(states)
            if state_count > self.partial_join_limit:
                return None
            levels.append(states)
            keys.append({_partial_state_key(state) for state in states})
        memory = _SemiNaivePositiveMemory(
            levels=levels,
            keys=keys,
            lookups=[
                self._build_partial_state_lookup(level, premise)
                if isinstance(premise, CompiledFactPremise)
                else None
                for level, premise in zip(
                    levels,
                    premises,
                    strict=True,
                )
            ],
            state_count=state_count,
        )
        final_states = self._advance_positive_states(
            tuple(levels[-1]),
            premises[-1],
            index,
        )
        return memory, self._activations_from_partial_states(
            final_states,
            index,
        )

    def _update_semi_naive_positive_memory(
        self,
        rule: Rule,
        index: FactIndex,
        memory: _SemiNaivePositiveMemory,
        delta: FactDelta,
    ) -> tuple[Activation, ...] | None:
        compiled_premises = compile_rule(rule).block.premises
        premises = tuple(
            premise
            for premise in compiled_premises
            if isinstance(
                premise,
                (CompiledFactPremise, CompiledComparisonPremise),
            )
        )
        if len(premises) != len(compiled_premises):
            raise TypeError("partial memory requires a positive rule")
        if delta.removed:
            for position, level in enumerate(memory.levels):
                retained = [
                    state
                    for state in level
                    if delta.removed.isdisjoint(state.supports)
                ]
                removed_count = len(level) - len(retained)
                if not removed_count:
                    continue
                memory.levels[position] = retained
                memory.keys[position] = {
                    _partial_state_key(state) for state in retained
                }
                if (
                    position == 0
                    or isinstance(
                        premises[position - 1],
                        CompiledFactPremise,
                    )
                ):
                    memory.state_count -= removed_count
                self.metrics.activation_cache_filtered += removed_count
                premise = premises[position]
                memory.lookups[position] = (
                    self._build_partial_state_lookup(retained, premise)
                    if isinstance(premise, CompiledFactPremise)
                    else None
                )
        if not delta.added:
            self.metrics.activation_cache_hits += 1
            return self._all_semi_naive_positive_activations(
                premises,
                memory,
                index,
            )

        new_prefixes: tuple[_PartialState, ...] = ()
        final_states: tuple[_PartialState, ...] = ()
        for position, premise in enumerate(premises):
            current = tuple(memory.levels[position])
            generated: list[_PartialState] = []
            if isinstance(premise, CompiledComparisonPremise):
                generated.extend(
                    state
                    for state in new_prefixes
                    if premise.source.evaluate(state.substitution)
                )
            elif isinstance(premise, CompiledFactPremise):
                generated.extend(
                    self._advance_positive_fact_states(
                        new_prefixes,
                        premise,
                        index,
                    )
                )
                generated.extend(
                    self._advance_positive_fact_states_from_delta(
                        current,
                        premise,
                        delta.added,
                        memory.lookups[position],
                    )
                )
            else:
                raise TypeError(
                    f"non-positive compiled premise: {premise!r}"
                )

            if position == len(premises) - 1:
                unique_final: dict[
                    tuple[
                        tuple[tuple[str, Term], ...],
                        tuple[Fact, ...],
                    ],
                    _PartialState,
                ] = {}
                for state in generated:
                    unique_final.setdefault(_partial_state_key(state), state)
                final_states = tuple(unique_final.values())
                break

            next_keys = memory.keys[position + 1]
            unique_new: list[_PartialState] = []
            for state in generated:
                key = _partial_state_key(state)
                if key not in next_keys:
                    next_keys.add(key)
                    unique_new.append(state)
            new_prefixes = tuple(unique_new)
            if not new_prefixes:
                continue
            memory.levels[position + 1].extend(new_prefixes)
            if isinstance(premise, CompiledFactPremise):
                memory.state_count += len(new_prefixes)
            if memory.state_count > self.partial_join_limit:
                return None
            next_premise = premises[position + 1]
            if isinstance(next_premise, CompiledFactPremise):
                lookup = memory.lookups[position + 1]
                if lookup is None:
                    memory.lookups[position + 1] = (
                        self._build_partial_state_lookup(
                            memory.levels[position + 1],
                            next_premise,
                        )
                    )
                else:
                    self._extend_partial_state_lookup(
                        lookup,
                        new_prefixes,
                    )
        if delta.removed:
            return self._all_semi_naive_positive_activations(
                premises,
                memory,
                index,
            )
        return self._activations_from_partial_states(final_states, index)

    def _all_semi_naive_positive_activations(
        self,
        premises: tuple[
            CompiledFactPremise | CompiledComparisonPremise,
            ...,
        ],
        memory: _SemiNaivePositiveMemory,
        index: FactIndex,
    ) -> tuple[Activation, ...]:
        final_states = self._advance_positive_states(
            tuple(memory.levels[-1]),
            premises[-1],
            index,
        )
        return self._activations_from_partial_states(final_states, index)

    def _build_partial_state_lookup(
        self,
        states: Sequence[_PartialState],
        premise: CompiledFactPremise,
    ) -> _PartialStateLookup | None:
        if not states:
            return None
        premise_variables = (
            variables_in(premise.source.entity)
            | variables_in(premise.source.status)
        )
        variables = tuple(
            sorted(
                (
                    variable
                    for variable in premise_variables
                    if variable in states[0].substitution
                ),
                key=lambda variable: variable.name,
            )
        )
        lookup = _PartialStateLookup(variables, {})
        self._extend_partial_state_lookup(lookup, states)
        return lookup

    @staticmethod
    def _extend_partial_state_lookup(
        lookup: _PartialStateLookup,
        states: Sequence[_PartialState],
    ) -> None:
        for state in states:
            key = tuple(
                state.substitution.apply(variable)
                for variable in lookup.variables
            )
            lookup.buckets.setdefault(key, []).append(state)

    def _advance_positive_fact_states_from_delta(
        self,
        states: Sequence[_PartialState],
        premise: CompiledFactPremise,
        candidates: Sequence[Fact],
        lookup: _PartialStateLookup | None,
    ) -> tuple[_PartialState, ...]:
        if not states or not candidates:
            return ()
        output: list[_PartialState] = []
        for fact in candidates:
            candidate_frame = BindingFrame()
            self.metrics.candidate_facts += 1
            self.metrics.match_attempts += 1
            if not premise.match(
                fact.entity,
                fact.status,
                candidate_frame,
            ):
                continue
            selected = (
                states
                if lookup is None
                else lookup.buckets.get(
                    tuple(
                        candidate_frame.apply(variable)
                        for variable in lookup.variables
                    ),
                    (),
                )
            )
            self.metrics.candidate_facts += len(selected)
            for state in selected:
                output.append(
                    _PartialState(
                        state.substitution.extend(
                            candidate_frame.freeze().items()
                        ),
                        (*state.supports, fact),
                    )
                )
        return tuple(output)

    @staticmethod
    def _activations_from_partial_states(
        states: Sequence[_PartialState],
        index: FactIndex,
    ) -> tuple[Activation, ...]:
        activations = [
            Activation(state.substitution, state.supports)
            for state in states
        ]
        return tuple(sorted(activations, key=index.activation_order))


def _normalize_delta(
    delta: FactDelta | tuple[Fact, ...] | None,
) -> FactDelta | None:
    if delta is None or isinstance(delta, FactDelta):
        return delta
    return FactDelta(added=delta)


@cache
def _has_reusable_positive_prefix(rule: Rule) -> bool:
    """Return whether a comparison blocks a later fact from reordering."""

    premises = compile_rule(rule).block.premises
    if not all(
        isinstance(
            premise,
            (CompiledFactPremise, CompiledComparisonPremise),
        )
        for premise in premises
    ):
        return False
    seen_comparison = False
    for premise in premises:
        if isinstance(premise, CompiledComparisonPremise):
            seen_comparison = True
        elif seen_comparison:
            return True
    return False


def _partial_state_key(
    state: _PartialState,
) -> tuple[tuple[tuple[str, Term], ...], tuple[Fact, ...]]:
    return state.substitution.key, state.supports


def _aggregate_accepts(
    premise: CountPremise | UniquePremise,
    count_value: int,
) -> bool:
    if isinstance(premise, UniquePremise):
        return count_value == 1
    return premise.accepts(count_value)
